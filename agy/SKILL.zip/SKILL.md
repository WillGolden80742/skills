# AGY - Skill de Gerenciamento de Tarefas

Delega tarefas para o agy com monitoramento via `agy-tasks/`.

## Estrutura

```
agy-tasks/
├── current/              # Tasks em execucao
│   ├── <uuid1>.md
│   └── <uuid2>.md
├── templates/
│   └── task-template.md  # Modelo replicavel
└── status.md             # Status geral
```

## Comandos

```bash
agy.py init                      # Inicializa estrutura
agy.py new "Titulo" "Desc"       # Cria nova task
agy.py list                      # Lista tasks
agy.py status                    # Mostra status
agy.py show <id>                 # Ver task especifica
agy.py set <id> <status>         # Atualiza status
agy.py note <id> "nota"          # Adiciona nota
agy.py done <id>                 # Marca concluida
```

## Status Values

- `pending` - Aguardando
- `in_progress` - Em andamento
- `completed` - Concluida

## Uso pelo OpenCode

1. Leia `agy-tasks/status.md` para ver progresso
2. Use `agy.py new` para criar tasks
3. Use `agy.py note` para registrar o que fez
4. Use `agy.py done` para marcar conclusao